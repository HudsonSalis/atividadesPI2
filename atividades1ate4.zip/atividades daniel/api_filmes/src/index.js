const express = require('express'); // Importando o express
const app = express();              // Inicializando
const port = 3000;                  // Porta a ser utilizada

app.use(express.json());


// Conexão Banco de Dados
async function conecta() {
    if ( global.conexao && global.conexao.state !== 'disconected' ) {
        return global.conexao;
    }

    const mysql = require('mysql2/promise');
    // mysql://usuario:senha@ipDoServidor:portaDoMysql/nomeDoBanco
    const conexao = await mysql.createconection('mysql://root@localhost:3306/iftm_filmes');
    console.log('Mysql conectado.');

    global.conexao = conexao;
    return conexao;
}

// Rotas
app.get('/', (req, res) => {
    return res.send('Servidor rodando agora');
})

//GET /filmes/:pagina 
app.get('/filmes/:pagina', async (req,res) =>{
    
    const con = await conecta();
    const {pagina} = req.params;
    
    let x = 10;
    let limite = (pagina * 10) - x; 
    const [atores] = await con.query('SELECT * FROM filmes ORDER BY nota DESC limit 10 offset ?',[ limite ]);
    return res.status(200).json(atores);
});

//GET /filme/:id
app.get('/filme/:id', async (req,res) =>{
    
    const con = await conecta();
    const {id} = req.params;
    
    //Utilizando a ? e substituindo no final pela palavra chave
    const [idFilme] = await con.query('SELECT * FROM filmes WHERE id = ?',[id]);
    const [genero] = await con.query('SELECT titulo FROM generos INNER JOIN filmes_generos ON filmes_generos.genero_id = generos.id WHERE filmes_generos.filme_id = ?',[id]);
    
    //Método concat para juntar todos 
    const concat = [].concat( idFilme , genero);
    return res.status(200).json(concat);
});

//GET /filmes/busca/:palavra
app.get('/filmes/busca/:palavra', async (req,res) =>{
    const conn = await conecta();
    const {palavra} = req.params;

    //Utilizando a ? e substituindo no final pela palavra chave
    const [idfilme] = await conn.query('SELECT * FROM filmes WHERE id = (SELECT id FROM filmes WHERE titulo = ?)' ,[palavra]);
    const [autor] = await conn.query('SELECT atores.titulo AS Atores FROM atores INNER JOIN atores_filmes ON atores_filmes.ator_id = atores.id WHERE atores_filmes.filme_id = (SELECT id FROM filmes WHERE titulo = ?)' ,[palavra]);
    const [genero] = await conn.query('SELECT generos.titulo AS Generos FROM generos INNER JOIN filmes_generos ON filmes_generos.genero_id = generos.id WHERE filmes_generos.filme_id = (SELECT id FROM filmes WHERE titulo = ?)' ,[palavra]);
    const concat = [].concat( idfilme , autor, genero);

    return res.status(200).json (concat);
});

//GET /generos/:genero 
app.get('/generos/:genero', async (req,res) =>{
    const con = await conecta();
    const {genero} = req.params;

    const [todosFilmes] = await con.query('SELECT titulo FROM filmes WHERE id IN (SELECT filme_id FROM filmes_generos WHERE genero_id = (SELECT id FROM generos WHERE titulo = ?))' ,[genero]);
    return res.status(200).json (todosFilmes);

});

//GET /ator/:id
app.get('/ator/:id', async (req,res) =>{

    const con = await conecta();

    const { id } = req.params;
    const [atorEfilmes] = await con.query('SELECT atores.titulo AS Ator, filmes.titulo AS Filme FROM atores INNER JOIN atores_filmes ON atores_filmes.ator_id = atores.id INNER JOIN filmes ON filmes.id = atores_filmes.filme_id WHERE atores.id = ?' ,[id]);
 
    return res.status(200).json (atorEfilmes);

});

//GET /atores/busca/:palavra

//POST /atores
app.post('/atores', async(req, res) =>{
        
    const con = await conecta();
    const {titulo} = req.body;
    
    const [ atores ] = await con.query('INSERT INTO atores.titulo VALUES (?)',[titulo]);

    try {
        return res.status(200).json('Sucesso, Ator criado: ', atores)
    } catch (error) {
        return res.status(500).json({ erro: 'Erro: Ator nao inserido.'})
    }
});

//PUT /atores
app.put('/atores', async(req, res) =>{
    
    const con = await conecta();

    const {id ,titulo} = req.body;

    const [ atores ] = await con.query('UPDATE atores SET titulo = ? WHERE id = ?',[ titulo , id ]);

    try {
        return res.status(200).json({ message: 'Sucesso, Ator editado:',id})
    } catch (error) {
        return res.status(500).json({ erro: 'Erro: Ator nao editado.'})
    }
   
    
});

//DELETE /atores/:id
app.delete('/atores/:id', async(req, res) =>{
   
    const {id } = req.params;
    const con = await conecta();

    const [ delAtores ] = await con.query('DELETE FROM atores WHERE id = ?',[id]);
    const [ del2Atores ] = await con.query('DELETE FROM atores_filmes WHERE ator_id = ?',[id]);

    try {
        return res.status(200).json({msg: 'Sucesso: Ator removido:' ,id})
    } catch (error) {
        return res.status(500).json({ erro: 'Erro: Ator não removido.'})
    }
      
});

//POST /participacoes/:idAtor/:idFilme
app.post('/participacoes/:idAtor/:idFilme', async (req, res) =>{
    
    const {idAtor,idFilme} = req.params;
    console.log(idAtor,idFilme);
    const con = await conecta();
    
    const [idParticipante] = await con.query('INSERT INTO atores_filmes (ator_id, filme_id) VALUES (?,?)',[idAtor,idFilme]);
    
    try {
        return res.status(200).json(idParticipante)
    } catch (error) {
        return res.status(500).json({ erro: 'Erro:  ID da tabela não encontrado.'})
    }

     
});

//DELETE /participacoes/:idAtor/:idFilme
app.delete('/participacoes/:idAtor/:idFilme', async (req, res) =>{
    
    const { idAtor,idFilme } = req.params;
    const con = await conecta();
    
    const [idParticicipação] = await con.query('DELETE FROM atores_filmes WHERE ator_id = ? AND filme_id = ?',[idAtor,idFilme]);
    
    try {
        return res.status(200).json({msg: 'Participação removida...'})
    } catch (error) {
        return res.status(500).json({ erro: 'Erro: Participação não pode ser removida.' })
    }

     
});

// Subir o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});


