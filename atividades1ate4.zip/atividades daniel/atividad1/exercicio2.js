const horaum = document.getElementById("horaum");
const horadois = document.getElementById("horadois");
const box = document.getElementById("box");
const btnEnviar = document.getElementById("btnEnviar");



btnEnviar.addEventListener("click", enviaMensagem);			

function enviaMensagem(e){

	const numero1 = horaum.value;
	const numero2 = horadois.value;
	const resultado = numero1 - numero2;

	box.innerHTML =  resultado;
}






