const p1 = document.getElementById("primeiroNumero");
const p2 = document.getElementById("segundoNumero");
const btnEnviar = document.getElementById("btnEnviar");



btnEnviar.addEventListener("click", enviaMensagem);			

function enviaMensagem(e){

	const msg = primeiroNumero.value;
	const msg1 = segundoNumero.value;

	if (msg == msg1) {
		alert("Números iguais, por favor coloque números diferentes.")
	}else {
		if (msg > msg1) {
			box.innerHTML = msg;
		}if (msg1 > msg) {
			box.innerHTML = msg1;
		}
	}
}






